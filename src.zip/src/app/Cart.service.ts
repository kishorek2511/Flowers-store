import {Injectable} from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';


@Injectable({
    providedIn: 'root'
  })

  export class CartService{
    private totalItems:BehaviorSubject<number> = new BehaviorSubject<number>(0);

    getCartItems(){
        return this.totalItems.asObservable();
    }

    updateCartItems(items: any){
        this.totalItems.next(items);
    }
  
    constructor() { }
  
    
  }