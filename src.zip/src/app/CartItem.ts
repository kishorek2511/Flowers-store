import { Products } from "./Products";


export class CartItem{
    id:string;
    name:string;
    imageUrl:string;
    unitPrice:number;
    quantity:number;

    constructor(product:Products){
        this.id = Products.id;
        this.name = Products.name;
        this.imageUrl = Products.imageUrl;
        this.unitPrice = Products.unitPrice;
        this.quantity = 1
    }
}