export class Category{
    constructor(
        public id = 0,
        public categoryName="" ,
        public imageUrl=""
           ) {}
}