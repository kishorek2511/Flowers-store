export class Contact{
    constructor(public id=0,
        public email="",
        public name="",
        public message="",
       
        ) {}
}