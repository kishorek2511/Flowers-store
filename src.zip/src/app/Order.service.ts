import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { Observable } from 'rxjs';
import {Order} from './Order';

@Injectable({
    providedIn: 'root'
  })

  export class OrderService{
    private baseUrl="http://localhost:8080/order";

    constructor(private httpClient: HttpClient) { }

    public getOrders(): Observable<Order[]>{
        return this.httpClient.get<any>(this.baseUrl+'/getOrders');
      }

    public addDetails(order :Order):Observable<Order[]>{
        return this.httpClient.post<any>(this.baseUrl+'/adddetails',order);
        }

        public SendEmail(order :Order):Observable<any>{
            return this.httpClient.post<any>(this.baseUrl+'/sendEmail',order);
            }
  }