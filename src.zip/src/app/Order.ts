export class Order{
  
    constructor(public id=0,
        public email="",
        public city="",
        public street="",
        public state="",
        public country="",
        public paymentType="",
        public message="",
        public subject=""
        ) {}
}