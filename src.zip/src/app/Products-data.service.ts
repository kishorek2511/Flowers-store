import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { BehaviorSubject, Observable } from 'rxjs';
import { Products } from './Products';
import { productAddedToCart } from './productAddedTocart';
import { Subject } from 'rxjs';

@Injectable({
    providedIn: 'root'
  })

export class ProductService{
  
  counter = 0;
  count!: BehaviorSubject<number>;

   private items:productAddedToCart[]=[];
   private product = new BehaviorSubject<productAddedToCart[]>([]);
    

     private baseUrl="http://localhost:8080/product/getAll";

    constructor(private httpClient: HttpClient){
      this.count  = new BehaviorSubject(this.counter);
    }
    
    public getProducts(): Observable<Products[]>{
      return this.httpClient.get<any>(this.baseUrl);
    }
   
    public getProductsByCategoryId(categoryId:number): Observable<Products[]>{
      console.log("service"+categoryId);
      return this.httpClient.get<any>(this.baseUrl+'/category/'+categoryId);
    }

    public getProductById(id:number): Observable<Products>{
      console.log("service"+id);
      return this.httpClient.get<any>(this.baseUrl+'/'+id);
    }

    public createProduct(products:Products): Observable<Products[]>{
      return this.httpClient.post<any>("http://localhost:8080/product/add",products);
    }

    public updateProduct(products:Products): Observable<Products>{
      
      return this.httpClient.put<any>(this.baseUrl+'/edit/'+products.id,products);
    }

    public deleteProduct(id:number): Observable<Products>{
      return this.httpClient.delete<any>(this.baseUrl+'/delete/'+id);
    }

    //To increase cart count
    increaseCount() {
      this.count.next(++ this.counter);
    }

    decreaseCount() {
      this.count.next(-- this.counter);
    }

    decreaseCountWhileDeleting(value:number){
      this.counter=this.counter-value;
     console.log("service counter"+this.counter);
      this.count.next(this.counter);
    }

    getProductData():Observable<productAddedToCart[]>{
      return this.product.asObservable();
    }
    
    
    addItem(item:productAddedToCart[]){
      this.product.next(item);
    }

    get Item():productAddedToCart[]{
      return this.items;
    }
}