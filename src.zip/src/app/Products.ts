import { Category } from "./Category";

export class Products{
    
    static id: string;
    static imageUrl: string;
    static unitPrice: number;
    static quantity: number;
    static size: string;
    static inventory:number;
    static categoryId:Category;

    constructor(
        public id=0,
        public name = "",
        public date="",
        public description = "",
        public unitPrice = 0,
        public imageUrl = "",
        public categoryId=0,
        public categoryName="" ,
        public quantity=0,
        public size='',
        public productid=0,
        public inventory=0,
        public sizeid =0
           ) {}

}