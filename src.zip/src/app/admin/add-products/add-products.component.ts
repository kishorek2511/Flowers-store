import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Products } from 'src/app/Products';
import { ProductService } from 'src/app/Products-data.service';
import { RegistrationService } from 'src/app/registration.service';
import {Category} from 'src/app/Category';
import { CategoryService } from 'src/app/Category-data.service';

@Component({
  selector: 'app-add-products',
  templateUrl: './add-products.component.html',
  styleUrls: ['./add-products.component.css']
})
export class AddProductsComponent implements OnInit {

  products:Products[]=[]
  product:Products= new Products(0,"","","",0,"",0,"",0);
  c:Category[]=[]
  category:Category= new Category(0,"","");

   constructor(private productService:ProductService, public router:Router,private register:RegistrationService,
    private categoryService:CategoryService) { }
 
   ngOnInit(): void {
   }
 
   createProduct(){
     this.productService.createProduct(this.product).subscribe(data =>{
      console.log(this.product)
      this.router.navigate(["/admindashboard"]);
     })
   }
 
   get isAdminLoggedIn(){
     if(this.register.loginStatus===1){
       return this.register.loginStatus;
     }else return 0;
   
   }
 

}
