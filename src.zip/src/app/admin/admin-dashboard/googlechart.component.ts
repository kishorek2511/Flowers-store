import { Component, OnInit } from '@angular/core';
import { ChartType } from 'angular-google-charts';
import { Order } from '../../Order';
import { OrderService } from '../../Order.service';
import { RegistrationService } from '../../registration.service';
import { User } from '../../user';
import { productAddedToCart } from '../../productAddedTocart';
import { Products } from 'src/app/Products';
import { Size } from 'src/app/size';
import { ProductService } from 'src/app/Products-data.service';
import { SizeService } from 'src/app/size.service';
import { element } from 'protractor';

@Component({
  selector: 'app-googlechart',
  templateUrl: './googlechart.component.html',
  styleUrls: ['./googlechart.component.css']
})
export class GooglechartComponent implements OnInit {
  order : Order[]=[];
  orders: Order=new Order(1,"","","","","","","");
  user: User[]=[];
  products: Products[] = [];
  product:Products[]=[];
  size:Size[]=[];
  sizes:Size[]= [];
  producttocart: productAddedToCart[]=[];
  

  constructor(private orderservice:OrderService,private registerService:RegistrationService,
     private productService:ProductService, private sizeService:SizeService) { }

  ngOnInit(): void {
    this.getUsers();
    this.getOrders();
    this.getProducts();
  }
 

 Data=new Array;
  title = "Customer Orders";
  mytype = ChartType.Table;
  
 columns = ['Count', 'Countries']; 
  count=0;
  count1=0;
  count2=0;
  Country='';
  getUsers(){
   this.registerService.getUsers().subscribe(element=>{
    this.user=element
    this.user.forEach(data=>{
      console.log(data.country)
      if(data.country=="India"){
      this.count++;
      
      }
      if(data.country=="Australia"){
        this.count1++;
        
        }
        if(data.country=="Australia"){
          this.count2++;
          
          }
    }) 
  this.Data.push(['India',this.count]);
  this.Data.push(['Australia',this.count1]);
  this.Data.push(['America',this.count2]);
   }) 
  }

  myData= new Array;
  myType = ChartType.ColumnChart;
  columnNames = ['Email ID', 'Order No'];
  options = { 
    alternatingRowStyle:true,
    showRowNumber:true  
  };
 Id:any;
  getOrders(){
    this.orderservice.getOrders().subscribe(data=>{
      this.order=data;
      this.order.forEach(element => {
         this.Id=element.id;
         this.orders.email=element.email;
        this.myData.push([this.orders.email,this.Id]);
      });
    }
      )
  }

  
  invData=new Array;
  Title = "Customer Orders";
  Type = ChartType.Table;
  
 columns1 = ['Id', 'Name','Size','Inventory']; 

  getProducts() {

    this.productService.getProducts().subscribe(data => {
      this.products = data;
      console.log(this.products);
      this.products.forEach(element=>{
        this.invData.push([element.id,element.name,element.size,element.inventory])
        console.log(this.invData)
      })
    
    });
  }

}
