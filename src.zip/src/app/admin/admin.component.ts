import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Products } from '../Products';
import { ProductService } from '../Products-data.service';
import { RegistrationService } from '../registration.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  products:Products[]=[]
 product:Products= new Products(0,"","","",0,"",0,"",0);
  constructor(private productService:ProductService, public router:Router,private register:RegistrationService) { }

  ngOnInit(): void {
  }

  createProduct(){
    this.productService.createProduct(this.product).subscribe(data =>{
     console.log(this.product)
     this.router.navigate(["/productsList"]);
    })
  }

  get isAdminLoggedIn(){
    if(this.register.loginValue===1){
      return this.register.loginValue;
    }else return 0;
  
  }

}
