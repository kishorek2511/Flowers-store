import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Products } from 'src/app/Products';
import { ProductService } from 'src/app/Products-data.service';

@Component({
  selector: 'app-edit-products',
  templateUrl: './edit-products.component.html',
  styleUrls: ['./edit-products.component.css']
})
export class EditProductsComponent implements OnInit {

  id=0;
  products: Products[]=[];
  product:Products | undefined;
  
  constructor(private productService:ProductService, 
    private activatedRoute: ActivatedRoute,private router:Router) { }

    
  ngOnInit() {
    
    this.id=this.activatedRoute.snapshot.params.id;
    console.log(this.id);
    
     this.getProductById()
  }

  
  getProductById() {
    
    this.productService.getProducts().subscribe(data => {
      this.products = data;
      this.products.forEach(element => {
        if (element.id == this.id ) { 
          this.name=element.name;
        this.price=element.unitPrice;
        this.image=element.imageUrl;
        this.description=element.description;
        this.sizeName=element.size;
        this.inventory=element.inventory;
               this.productService.getProductById(this.id).subscribe(data => {
        this.product = data;
      });
        }
      });
    });
  }

  price=0;
  name="";
  image="";
  description="";
  sizeName="";
  inventory=0;
  updateProduct() {

    this.productService.getProducts().subscribe(data => {
      this.products = data;
    
      this.productService.getProductById(this.id).subscribe(res =>{
       
        this.product=res;
        this.product.unitPrice=this.price;
        this.product.name=this.name;
        this.product.imageUrl=this.image;
        this.product.size=this.sizeName;
        this.product.inventory=this.inventory;
        this.product.description=this.description;
        
        this.productService.updateProduct(this.product).subscribe(data1=>{
          this.product=data1
          this.router.navigate(["/admindashboard"]);
        })
      })
       
    });
  }

}
