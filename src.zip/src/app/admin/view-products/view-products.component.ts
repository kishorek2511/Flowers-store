import { Component, OnInit } from '@angular/core';
import { productAddedToCart } from 'src/app/productAddedTocart';
import { Products } from 'src/app/Products';
import { ProductService } from 'src/app/Products-data.service';
import { Size } from 'src/app/size';
import { SizeService } from 'src/app/size.service';

@Component({
  selector: 'app-view-products',
  templateUrl: './view-products.component.html',
  styleUrls: ['./view-products.component.css']
})
export class ViewProductsComponent implements OnInit {

  products: Products[] = [];
  product:Products[]=[];
  size:Size[]=[];
  sizes:Size[]= [];
  
  producttocart: productAddedToCart[]=[];
  constructor(private productService:ProductService) { }

  ngOnInit(): void {
    this.productService.getProducts().subscribe(data => {
      this.products = data;
      console.log(this.products)
    });
  }
  

  getProducts() {

    this.productService.getProducts().subscribe(data => {
      this.products = data;
      console.log(this.products)
    });
  }

  
  deleteProduct(prodId:number){
    console.log(prodId)
    this.productService.deleteProduct(prodId).subscribe(data=>{
      this.getProducts();
    })
  }

  sort(event: any) {
    switch (event.target.value) {
      case "Low":
        {
          this.productService.getProducts().subscribe(data=>{
            this.products=data;
          this.products = this.products.sort((low, high) => low.unitPrice - high.unitPrice);
          })
          break;
        }

      case "High":
        {
          this.productService.getProducts().subscribe(data=>{
            this.products=data;
          this.products = this.products.sort((low, high) => high.unitPrice - low.unitPrice);
          })
          break;
        }

        case "Small":
          {
            this.productService.getProducts().subscribe(data=>{
              this.products=data; 
            this.products = this.products.filter(x=>x.size=="Small");
            
            console.log(this.products);
            })
            break;
          }

          case "Medium":
            {
              this.productService.getProducts().subscribe(data=>{
                this.products=data; 
              this.products = this.products.filter(x=>x.size=="Medium");
              
              console.log(this.products);
              })
              break;
            }

            case "Large":
              {
                this.productService.getProducts().subscribe(data=>{
                  this.products=data; 
                this.products = this.products.filter(x=>x.size=="Large");
                
                console.log(this.products);
                })
                break;
              }

              case "New Arrival":
              {
                this.productService.getProducts().subscribe(data=>{
                  this.products=data;
                this.products = this.products.sort((a, b) =>  Date.parse(b.date)-  Date.parse(a.date));
                })
               console.log(this.products)
                break;
              }

      default: {
     
        break;
      }

    }
    

  }
}
