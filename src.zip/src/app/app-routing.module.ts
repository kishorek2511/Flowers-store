import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { EditProductsComponent } from './admin/edit-products/edit-products.component';
import { ViewProductsComponent } from './admin/view-products/view-products.component';
import { CheckoutpageComponent } from './checkoutpage/checkoutpage.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { GooglechartComponent } from './admin/admin-dashboard/googlechart.component';
import { LocationComponent } from './location/location.component';
import { LoginComponent } from './login/login.component';
import { LoginsuccessComponent } from './loginsuccess/loginsuccess.component';
import { ProductdescriptionpageComponent } from './productdescriptionpage/productdescriptionpage.component';
import { ProductlistingpageComponent } from './productlistingpage/productlistingpage.component';
import { RegistrationComponent } from './registration/registration.component';
import { ShopComponent } from './shop/shop.component';
import { ShoppingcartpageComponent } from './shoppingcartpage/shoppingcartpage.component';
import { AddProductsComponent } from './admin/add-products/add-products.component';

const routes: Routes = [
  {path:'shop',component:ShopComponent},
  {path:'loginsuccess',component:LoginsuccessComponent},
  {path:'registration',component:RegistrationComponent},
  {path:'login',component:LoginComponent},
  {path: 'category/:id', component: ProductlistingpageComponent},
  {path: 'category/all', component: ProductlistingpageComponent},
  {path: 'product/:id', component: ProductdescriptionpageComponent},
  {path: 'products/cart', component: ShoppingcartpageComponent},
  {path: 'products/checkout', component: CheckoutpageComponent},
  {path: 'contact', loadChildren:()=>import('./contactpage/contactpage.module').then(m=>m.ContactpageModule)},
  {path: 'location', component: LocationComponent},
  {path: 'admin', component: AdminComponent},
  {path: 'admindashboard', component: ViewProductsComponent},
  {path: 'Edit/:id', component: EditProductsComponent},
  {path: 'addProducts', component: AddProductsComponent},
  {path: 'forgotpassword', component: ForgotpasswordComponent},
  {path: 'feedback', loadChildren:()=>import('./feedback/feedback.module').then(m=>m.FeedbackModule)},
  {path: 'reports', component: GooglechartComponent},
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
