import { Component } from '@angular/core';
import { RegistrationService } from './registration.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'online-flower-store';

 constructor(public register:RegistrationService){

 }
 logout(){
   this.register.setLoginStatus(0);
   this.register.setLoginValue(0);
 }

  get isAdmin(){
   if(this.register.loginValue===1){
     return this.register.loginValue;
   }else return 0;
 }
 }
