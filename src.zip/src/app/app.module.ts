import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { GoogleChartsModule } from 'angular-google-charts';  
import { NgxPaginationModule } from 'ngx-pagination';
import { JwPaginationModule } from 'jw-angular-pagination';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { LoginsuccessComponent } from './loginsuccess/loginsuccess.component';
import { ShopComponent } from './shop/shop.component';
import { ProductlistingpageComponent } from './productlistingpage/productlistingpage.component';
import { ProductdescriptionpageComponent } from './productdescriptionpage/productdescriptionpage.component';
import { CartCountComponent } from './cart-count/cart-count.component';
import { ShoppingcartpageComponent } from './shoppingcartpage/shoppingcartpage.component';
import { CheckoutpageComponent } from './checkoutpage/checkoutpage.component';
import { LocationComponent } from './location/location.component';
import { AdminComponent } from './admin/admin.component';
import { ViewProductsComponent } from './admin/view-products/view-products.component';
import { EditProductsComponent } from './admin/edit-products/edit-products.component';
import { DeleteProductsComponent } from './admin/delete-products/delete-products.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { GooglechartComponent } from './admin/admin-dashboard/googlechart.component';
import { AddProductsComponent } from './admin/add-products/add-products.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FilterPipe } from './filter.pipe';




const routes: Routes =[
   {path: 'products', component: ShopComponent},
  
   {path: '', redirectTo: '/products', pathMatch:'full'}
];

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegistrationComponent,
    LoginsuccessComponent,
    ShopComponent,
    ProductlistingpageComponent,
    ProductdescriptionpageComponent,
    CartCountComponent,
    ShoppingcartpageComponent,
    CheckoutpageComponent,
    LocationComponent,
    AdminComponent,
    ViewProductsComponent,
    EditProductsComponent,
    DeleteProductsComponent,
    ForgotpasswordComponent,
    GooglechartComponent,
    AddProductsComponent,
    FilterPipe
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    GoogleChartsModule.forRoot(),
    NgxPaginationModule,
    JwPaginationModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
