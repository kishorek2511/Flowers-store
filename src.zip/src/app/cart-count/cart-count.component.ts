import { Component, OnInit,Input } from '@angular/core';
import { CartService } from '../Cart.service';
import { ProductService } from '../Products-data.service';

@Component({
  selector: 'app-cart-count',
  templateUrl: './cart-count.component.html',
  styleUrls: ['./cart-count.component.css']
})
export class CartCountComponent implements OnInit {
  @Input()
  cartCount!:number;
  count=0;

  constructor(private _cartService: CartService,private productService:ProductService) { }

  ngOnInit() {

    this.productService.count.subscribe(c => {
      this.count = c;
      console.log("cartcount is"+c);
    });
  
  }
 
}
