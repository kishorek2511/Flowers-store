import { Component, OnInit } from '@angular/core';
import { RegistrationService } from '../registration.service';
import { Order } from '../Order';
import { OrderService } from '../Order.service';import { ProductService } from '../Products-data.service';
;

@Component({
  selector: 'app-checkoutpage',
  templateUrl: './checkoutpage.component.html',
  styleUrls: ['./checkoutpage.component.css']
})
export class CheckoutpageComponent implements OnInit {
 
  order : Order[]=[];
  orders: Order=new Order(0,"","","","","","","","Order Confirmation");
  isFormSubmitted=false;
  msg='';
  constructor(public register:RegistrationService,public orderservice:OrderService,private productService:ProductService) { }

 ngOnInit(){

 }

  get isLoggedIn(){
    if(this.register.loginStatus===1){
      return this.register.loginStatus;
    }else return 0;
  }

  getValue(event:Event){
    console.log(event)
  }

 Id="";
 paymenttype="";
 count=0;
 showMsg: boolean=false;
  SubmitDetails(){
    this.isFormSubmitted=true;
    this.orderservice.SendEmail(this.orders).subscribe(
      data => {
      this.orders=data;
      this.orders.id=this.orders.id+1;
      console.log(this.orders);
      this.showMsg=true;
      this.productService.count.subscribe(c => {
        c=0;
        console.log("cartcount is"+c);
      });
      },
      error => {
        console.log("exception occured");
        this.msg="Please fill the required details";
      }
    )
  
   }

  Click(event:any){
 this.paymenttype=event.target.value;
 console.log(this.paymenttype)
  }
}

