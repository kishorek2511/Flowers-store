import { Component, OnInit } from '@angular/core';
import {Contact} from '../Contact'
import { ContactService } from '../Contact.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-contactpage',
  templateUrl: './contactpage.component.html',
  styleUrls: ['./contactpage.component.css']
})
export class ContactpageComponent implements OnInit {
  contact : Contact[]=[];
  contacts: Contact=new Contact(0,"","","");
  msg='';
  constructor(private contactService:ContactService) { }

  ngOnInit(): void {
  }

  showMsg: boolean=false;
  sendMessage(){
    this.contactService.SendEmail(this.contacts).subscribe(
      data => {
        this.contacts=data;
       console.log(this.contacts);
 
     this.showMsg=true;
      },
      error =>{
        this.msg="Please fill the required details";
      }
    )
  }
}
