import {NgModule} from "@angular/core";
import {CommonModule} from "@angular/common";
import {FormsModule} from '@angular/forms';
import {ContactPageRoutingModule} from "./contactpage-routing.module";
import {ContactpageComponent} from "./contactpage.component";

@NgModule({
    imports:[CommonModule, FormsModule,ContactPageRoutingModule],
    declarations:[ContactpageComponent]
})

export class ContactpageModule{}