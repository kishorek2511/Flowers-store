import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { Observable } from 'rxjs';
import {Feedback} from './feedback';

@Injectable({
    providedIn: 'root'
  })

  export class FeedbackService{
    private baseUrl="http://localhost:8080/Feedback";

    constructor(private httpClient: HttpClient) { }

    public SendEmail(feedback :Feedback):Observable<any>{
        return this.httpClient.post<any>(this.baseUrl+'/sendEmail',feedback);
        }
  }