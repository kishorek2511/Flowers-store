export class Feedback{
    constructor(public id=0,
        public email="",
        public rating=0,
        public message="",
       
        ) {}
}