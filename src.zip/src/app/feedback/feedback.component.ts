import { Component, OnInit } from '@angular/core';
import { Feedback } from '../feedback';
import { FeedbackService } from '../feedback.service';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {

  feedback : Feedback[]=[];
   Feedback=new Feedback(0,"",0,"");
  stars: number[] = [1, 2, 3, 4, 5];
  selectedValue:any;
  constructor(private feedbackService:FeedbackService) { }

  ngOnInit(): void {
  }
 
  showMsg: boolean=false;
  sendMessage(){
    this.feedbackService.SendEmail(this.Feedback).subscribe(
      data => {
        this.Feedback.rating=this.selectedValue;
       console.log(this.Feedback);
     this.showMsg=true;
     
      }
    )
  }

  
  countStar(star:any) {
    this.selectedValue = star;
    console.log('Value of star', star);
  }
}
