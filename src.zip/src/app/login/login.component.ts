import { Route } from '@angular/compiler/src/core';
import { Component, OnInit } from '@angular/core';
import {NgForm} from '@angular/forms';
import { Router } from '@angular/router';
import { RegistrationService } from '../registration.service';
import { User } from '../user';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user = new User();
  msg='';
  constructor(private _service: RegistrationService, private _router:Router) { }

  ngOnInit(): void {
  }

  loginUser(){
    this._service.loginUserFromRemote(this.user).subscribe(
      data =>{ console.log("response recieved");
      console.log(data.userType)
      if(data.userType=="Admin"){
       this._service.setLoginValue(1);
        this._service.setLoginStatus(1);
        this._router.navigate(['/admindashboard']);
      }
      else{
        console.log("user")
        this._service.setLoginValue(0);
        this._service.setLoginStatus(1);
      this._router.navigate(['/shop']);
      }
      

    },
      error => {
        console.log("exception occured");
        this.msg="Please enter valid details";
    });


  }


}
