export class productAddedToCart{
    static id: string;
    static imageUrl: string;
    static unitPrice: number;
    static quantity: number;

    constructor(
        public id=0,
        public name = "",
        public description = "",
        public unitPrice = 0,
        public imageUrl = "",
        public size="",
        public date="",
        public productid=0,
        public quantity=0,
        public inventory=0
           ) {}

}