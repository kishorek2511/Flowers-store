import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductdescriptionpageComponent } from './productdescriptionpage.component';

describe('ProductdescriptionpageComponent', () => {
  let component: ProductdescriptionpageComponent;
  let fixture: ComponentFixture<ProductdescriptionpageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductdescriptionpageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductdescriptionpageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
