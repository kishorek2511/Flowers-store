import { Identifiers } from '@angular/compiler';
import { Component, EventEmitter, OnInit,Output } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CartService } from '../Cart.service';
import { CategoryService } from '../Category-data.service';
import { productAddedToCart } from '../productAddedTocart';
import { Products } from '../Products';
import { ProductService } from '../Products-data.service';
import { Size } from '../size';
import { SizeService } from '../size.service';

@Component({
  selector: 'app-productdescriptionpage',
  templateUrl: './productdescriptionpage.component.html',
  styleUrls: ['./productdescriptionpage.component.css']
})
export class ProductdescriptionpageComponent implements OnInit {
  Id=0;
  products: Products[]=[];
  product!: Products;
  sizeName="";
  isSelected=false;

  constructor(private productService:ProductService, 
    private activatedRoute: ActivatedRoute, private categoryService:CategoryService,private sizeService:SizeService) { }

    
  ngOnInit() {
    
    this.Id=this.activatedRoute.snapshot.params.id;
    console.log(this.Id);
   
      this.getProductById();
      this.getSizesByProductId();
        
  }

  productId=0;
  Name='';
  Price=0;
  ImageUrl='';
  Quantity=0;
  Size='';
  Description='';
  getProductById() {
  this.productService.getProductById(this.Id).subscribe(data => {
        this.product = data;
        this.Name=data.name;
        this.Price=data.unitPrice;
        this.Quantity=1;
        this.ImageUrl=data.imageUrl;
        this.productId = data.id;
        this.Size=data.size;
        this.Inventory=data.inventory;
        this.Description=data.description;
      });
       
  }

  count=0;
  getSizesByProductId(){
    
      this.productService.getProducts().subscribe(element=>{
      this.products=element;
      this.products.forEach(data=>{
        if(data.productid==this.Id)
        {
          this.count++;
          
          this.products.push(data);
        }
      })
      this.products=this.products.splice(this.products.length-this.count,this.count);
    console.log(this.products)
          })
    
  }

  onClick(event:any) {
   this.sizeName=event.target.value;
   console.log(event.target.value);
   this.isSelected=true;
   this.products.forEach(data => {
         if(data.productid==this.Id && data.size==this.sizeName){
           this.Price=data.unitPrice;
           console.log(this.Price)
         }
   })
  }
  
index=0;
Inventory=0;
msg='';
producttocart: productAddedToCart[]=[];
  addToCart(product:Products){
    this.productService.getProductData().subscribe(data=>{
      this.producttocart=data;
    })
   
  
   if(this.producttocart.length==0 || this.producttocart.findIndex(x=>x.productid==this.Id && x.size==this.sizeName)== -1) {
    
    this.products.forEach(data=>{
      if(data.size==this.sizeName && data.inventory>0){
        this.productService.increaseCount(); 
         data.inventory =data.inventory-1;
         this.Inventory=data.inventory;
         this.producttocart.push({id:data.id,name:data.name,description:data.description,
          imageUrl:data.imageUrl,unitPrice:data.unitPrice,productid:data.productid,
         quantity:1,size:this.sizeName,inventory:this.Inventory,date:data.date
        });
        
        this.productService.getProductById(data.id).subscribe(res =>{
          this.product=res;
          this.product.inventory=this.Inventory;
          this.productService.updateProduct(this.product).subscribe(data1=>{
            this.product=data1;
          })
        })
        this.productService.addItem(this.producttocart);
      }
      else if(data.inventory==0){
        this.msg="Out of stock";
      }
      
    })
   }
     else{
      this.producttocart.forEach(element => {

    if(element.productid==this.Id && element.size==this.sizeName){
     
      this.products.forEach(data=>{
        if(data.size==this.sizeName && data.inventory>0){
         
           data.inventory=data.inventory-1;
           this.Inventory=data.inventory;
           
           this.productService.getProductById(data.id).subscribe(res =>{
       
            this.product=res;
            this.product.inventory=this.Inventory;
            this.productService.updateProduct(this.product).subscribe(data1=>{
              this.product=data1;
            })
          })
          element.inventory=this.Inventory;
          element.quantity=element.quantity+1;
          this.productService.increaseCount(); 
          console.log(this.producttocart)
        }
        else{
          this.msg="Out of stock";
        }
  
      })
    
    }   
   })
   
  }
 
  }
}


