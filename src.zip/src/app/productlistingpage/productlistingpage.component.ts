import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CategoryService } from '../Category-data.service';
import { Products } from '../Products';
import { ProductService } from '../Products-data.service';
import { Size } from '../size';
import { SizeService } from '../size.service';

@Component({
  selector: 'app-productlistingpage',
  templateUrl: './productlistingpage.component.html',
  styleUrls: ['./productlistingpage.component.css']
})
export class ProductlistingpageComponent implements OnInit {
id:any;
  products: Products[]=[];
  product!:Products ;
  config: any;
  collection = { count: 60, data: [] };
  
  constructor(private productService:ProductService, 
    private activatedRoute: ActivatedRoute, private categoryService:CategoryService) {
      
this.config = {
  itemsPerPage: 20,
  currentPage: 1,
  totalItems: this.products.length
};
     }

    
  ngOnInit() {
    
    this.id=this.activatedRoute.snapshot.params.id;
   
      this.getProductsByCategory();    
      
  }

  getProductsByCategory() {
    if(this.id=='all'){
      this.productService.getProducts().subscribe(data=>{
        this.products=data;
      })
    }
    else{
      this.productService.getProductsByCategoryId(this.id).subscribe(data => {
        this.products = data;
    });
  }
  }


  sort(event: any) {
    switch (event.target.value) {
      case "Low":
        {
          
          this.products = this.products.sort((low, high) => low.unitPrice - high.unitPrice);
          break;
        }

      case "High":
        {
        
          this.products = this.products.sort((low, high) => high.unitPrice - low.unitPrice);
          break;
        }

        case "All":
        {
        
      this.getProductsByCategory() ;
          break;
        }

        case "New Arraival":
          {
            this.products = this.products.sort((a, b) =>  Date.parse(b.date)-  Date.parse(a.date));
           console.log(this.products)
            break;
          }

      default: {
     
        break;
      }

    }
    

  }

  //View by Size
  count=0;
  Click(event:any){
   this.productService.getProductsByCategoryId(this.id).subscribe(data=>{
     this.products=data;
    this.count=0;
    this.products.forEach(data=>{
      if(data.size==event.target.value){
        this.count++;
        this.products.push(data);
       console.log(this.products)
      }   
    })
    this.products=this.products.splice(this.products.length-this.count,this.count);
  })
  }

pageChanged(event:any){
this.config.currentPage = event;
}
 


}