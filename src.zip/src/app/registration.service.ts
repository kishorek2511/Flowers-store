import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from './user';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class RegistrationService {

  loginStatus=0;
  loginValue=0;
  constructor(private _http: HttpClient) { }

  public loginUserFromRemote(user :User):Observable<any>{
  return this._http.post<any>("http://localhost:8080/login",user);
  }

  public registerUserFromRemote(user :User):Observable<any>{
    return this._http.post<any>("http://localhost:8080/registeruser",user);
    }

    public getUsers():Observable<User[]>{
      return this._http.get<any>("http://localhost:8080/getusers");
    }

    setLoginStatus(status:number){
      this.loginStatus=status;
    }

    setLoginValue(value:number){
      this.loginValue=value;
    }
}
