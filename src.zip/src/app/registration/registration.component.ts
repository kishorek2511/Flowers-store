import { Component, OnInit } from '@angular/core';
import {
  FormGroup,
  FormControl,
  FormBuilder,
  Validators,
  NgForm
} from "@angular/forms";
import { Router } from '@angular/router';
import { RegistrationService } from '../registration.service';
import { User } from '../user';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  user = new User(0,"","","","","","","");
  msg='';
  SelectedCity='';
  SelectedCountry='';
  isFormValid=true;
  submitted=false;
  constructor(private _service: RegistrationService, private _router: Router) { }

  ngOnInit(): void {
    
  }

  registerUser(){
   this._service.registerUserFromRemote(this.user).subscribe(
     data => {
      
       this.user=data;
       this.user.city=this.SelectedCity;
       console.log(this.user.city)
       console.log(this.user);
       this.isFormValid=true;
       this.submitted=true;
       console.log("response recieved");
       this._router.navigate(['/login'])
     },
     error => {
       this.isFormValid=false;
       
       this.submitted=true;
       console.log("exception occured");
       this.msg="Please enter required details"
     }
   )
  }
  
  selectCity(event:any){
    this.SelectedCity=event.target.value;
  }

  selectCountry(event:any){
    this.SelectedCountry=event.target.value;
  }
}
