import { NgIf } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { fadeInAnimation } from '../animation';
import { Category } from '../Category';
import { CategoryService } from '../Category-data.service';

import { Products } from '../Products';
import {ProductService} from "../Products-data.service";

@Component({
  selector: 'app-shop',
 
  templateUrl: './shop.component.html',
  styleUrls: ['./shop.component.css'],// make fade in animation available to this component
  animations: [fadeInAnimation],

  // attach the fade in animation to the host (root) element of this component
  host: { '[@fadeInAnimation]': '' }
})
export class ShopComponent implements OnInit {
  category: Category[] = [];
  

  constructor(
    private activatedRoute: ActivatedRoute, private categoryService:CategoryService) { }
  
  ngOnInit(): void {
    this.getCategories();
  }

  
  
  getCategories(){
    this.categoryService.getCategories().subscribe(data => {
      this.category = data;
    });
    
  }

 
}
