import { Component, Input, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { CartService } from '../Cart.service';
import { productAddedToCart } from '../productAddedTocart';
import { Products } from '../Products';
import { ProductService } from '../Products-data.service';

@Component({
  selector: 'app-shoppingcartpage',
  templateUrl: './shoppingcartpage.component.html',
  styleUrls: ['./shoppingcartpage.component.css']
})
export class ShoppingcartpageComponent implements OnInit {

  product: productAddedToCart[]=[];
  products!: productAddedToCart;
  count=0;

  constructor(private productService:ProductService, private cartService:CartService) { }
  
  total!: number;
  ngOnInit(): void {
  
  this.productService.getProductData().subscribe(data=>{
    this.product=data;
  })
  }
  
    increase(product:any){
      product.quantity=product.quantity+1;
     
      this.productService.increaseCount();
  }


    decrease(product:any){
      product.quantity=product.quantity-1;
      this.productService.decreaseCount();
    }

   
    c=0;
    deleteProduct(index: number){
      
      this.product.forEach(element => {
        if(index==this.product.indexOf(element)){
          this.productService.decreaseCountWhileDeleting(element.quantity); //decreasing the cart quantity
        }
       });
          this.product.splice(index,1);  
        
    }

    cartCount(){
      if(this.product.length>0){
        return true;
      }
      else
      return false;
    }
  
    orderTotal(){
      var sum=0;
      this.product.forEach(element => {
        sum=sum+(element.quantity*element.unitPrice);
      });
         return sum;
    }

  
}

