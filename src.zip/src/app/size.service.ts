import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { Observable } from 'rxjs';
import {Size} from './size';

@Injectable({
    providedIn: 'root'
  })

  export class SizeService{
    private baseUrl="http://localhost:8080/size/getAll";

    constructor(private httpClient: HttpClient) { }


    public getSizesByProductId(sizeId:number): Observable<Size[]>{
        console.log("service"+sizeId);
        return this.httpClient.get<any>(this.baseUrl+'/product/'+sizeId);
      }

      public getSizes(): Observable<Size[]>{
        return this.httpClient.get<any>(this.baseUrl);
      }
  }