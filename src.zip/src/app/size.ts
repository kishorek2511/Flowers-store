export class Size{
    constructor(
        public id=0,
        public name = "",
        public productid=0,
        public sizeid=0,
        public inventory=0
           ) {}
}