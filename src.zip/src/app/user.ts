export class User {
  
    constructor(public id=0,
        public emailId="",
        public firstName="",
        public lastName="",
        public password="",
        public userType="",
        public city="",
        public country="",
        public checkbox=false
        ) {}
}
